function Z = convolution_new(X,Filter)
   
   LenF    = length(Filter);
   HalfLen = fix(LenF/2);
   Width   = length(X);
   
   
   
   Exp1=X(:,HalfLen:-1:1);
   Exp2=X(:,Width-1:-1:Width-HalfLen);
   Y = [Exp1,X,Exp2];
   Med_M=zeros(LenF,Width);
   
   for i=1:LenF
       Med_M(i,:)=Y(i:i+Width-1);
   end
   
   Med_M=Med_M';
   Z=Med_M*Filter';
   
%    Result = zeros(Height,Width);
%    Exp1 = zeros(Height,HalfLen);
%    Exp2 = Exp1;
% 
%    a = HalfLen +1;
%    c = LenF-1;
%    
%    for i = 1:HalfLen
%       Exp1(:,a-i) = X(:,i+1);
%       Exp2(:,i)=X(:,Width-i);
%    end
%    
%    Y = [Exp1,X,Exp2];
%    
%    for i = 1:Width
%        Result(:,i) = Y(:,i:i+c)*Filter';
%    end
%    Z = Result;
   