
% Compare T-junctions with obtained corners and add T-junctions to corners
% which are far away (outside a 5 by 5 neighborhood) from detected corners
function [corner_final c3] = Refine_TJunctions(corner_out,TJ,c2,curve, curve_num, curve_start, curve_end, curve_mode,EP)
%corner_final = corner_out;
c3=c2;
%%%%% add end points
if EP
    corner_num = size(corner_out,1);
    for i=1:curve_num
            if size(curve{i},1)>0 & curve_mode(i,:)=='line'

                % Start point compare with detected corners
                compare_corner=corner_out-ones(size(corner_out,1),1)*curve_start(i,:);
                compare_corner=compare_corner.^2;
                compare_corner=compare_corner(:,1)+compare_corner(:,2);
                if min(compare_corner)>100       % Add end points far from detected corners 
                    corner_num=corner_num+1;
                    corner_out(corner_num,:)=curve_start(i,:);
                    c3 = [c3;8];
                end

                % End point compare with detected corners
                compare_corner=corner_out-ones(size(corner_out,1),1)*curve_end(i,:);
                compare_corner=compare_corner.^2;
                compare_corner=compare_corner(:,1)+compare_corner(:,2);
                if min(compare_corner)>100
                    corner_num=corner_num+1;
                    corner_out(corner_num,:)=curve_end(i,:);
                    c3 = [c3;9];
                end
            end
    end
end
%%%%%%%%%%%%%%%5

%%%%%Add T-junctions
corner_final = corner_out;
for i=1:size(TJ,1)
    % T-junctions compared with detected corners
    if size(corner_final)>0
        compare_corner=corner_final-ones(size(corner_final,1),1)*TJ(i,:);
        compare_corner=compare_corner.^2;
        compare_corner=compare_corner(:,1)+compare_corner(:,2);
        if min(compare_corner)>100       % Add end points far from detected corners, i.e. outside of 5 by 5 neighbor
            corner_final = [corner_final; TJ(i,:)];
            c3 = [c3;10];
        end
    else
        corner_final = [corner_final; TJ(i,:)];
        c3 = [c3;10];
    end
end