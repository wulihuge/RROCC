image=imread('03.gif');
if size(image,3)==3
    image=rgb2gray(image);
end

BW=edge(image,'canny_old',[0.2,0.7]);
Gap_size=1;
[curve,curve_start,curve_end,curve_mode,curve_num,TJ]=extract_curve(BW,Gap_size);


curvature_thresh=0.065;%%%curvature threshold
cout=[];
sig=3.5;%%%Gaussian smoothing factor 
n=3;%%%RoS
len=2;%%%the curvature value at a corner should be larger than its neighbour points with RoS equals to 2 



for jj=1:curve_num
 [m s]=size(curve{jj});
 
 x=curve{jj}(:,1);
 y=curve{jj}(:,2);
%%%curve smoothing
 L=size(x,1);
 MS_Curvature=zeros(m,2);


        [gau, width] = myfilter(sig,'gaussian');
		W=width;
		if L>W
            if curve_mode(jj,:)=='loop'
                x1=[x(L-W+1:L);x;x(1:W)];
                y1=[y(L-W+1:L);y;y(1:W)];
            else
                x1=[ones(W,1)*2*x(1)-x(W+1:-1:2);x;ones(W,1)*2*x(L)-x(L-1:-1:L-W)];
                y1=[ones(W,1)*2*y(1)-y(W+1:-1:2);y;ones(W,1)*2*y(L)-y(L-1:-1:L-W)];
            end
        end        
            if size(x1,1)>1
                x1=x1';
            end
            if size(y1,1)>1
                y1=y1';
            end

            xx = convolution_new(x1, gau)';
            yy = convolution_new(y1, gau)';
%%%curve smoothing

    xx=xx(:);
    yy=yy(:);
    x_exp=xx(W-n+1:m+W+n);
    y_exp=yy(W-n+1:m+W+n);
    
    u=zeros(m,2*n);
    v=u;
    x_med=x_exp(n+1:n+m);
    y_med=y_exp(n+1:n+m);
    
    D=zeros(m,2*n);
    
    for i=1:n
       
       u(:,i)=x_exp(i:i+m-1)-x_med;
       v(:,i)=y_exp(i:i+m-1)-y_med;
       u(:,n+i)=x_exp(n+i+1:n+i+m)-x_med;
       v(:,n+i)=y_exp(n+i+1:n+i+m)-y_med;

    end
    
    w=(u.^2+v.^2)/2;
    sum_u2=sum(u.^2,2);
    sum_v2=sum(v.^2,2);
    sum_w2=sum(w.^2,2);
    sum_uw=sum(u.*w,2);
    sum_vw=sum(v.*w,2);
    sum_uv=sum(u.*v,2);

    
    a=sum_u2-(sum_uw.^2)./sum_w2;
    b=sum_uv-(sum_uw.*sum_vw)./sum_w2;
    c=sum_v2-(sum_vw.^2)./sum_w2;

    Lamda_min=(a+c-sqrt((a-c).^2+4*b.^2))/2;
    
    n1=sqrt((Lamda_min-a).^2+b.^2);
    n2=sqrt((Lamda_min-c).^2+b.^2);
    Eigen_vector=[b,Lamda_min-a];
    Index_med=find(n2>n1);
    Eigen_vector(Index_med,:)=[Lamda_min(Index_med)-c(Index_med),b(Index_med)];
    Norm_med=sqrt(sum(Eigen_vector.^2,2));
    Norm_Eigen=[Norm_med,Norm_med];
    Eigen_vector=Eigen_vector./Norm_Eigen;

    RROCC_curvature=abs((sum_uw.*Eigen_vector(:,1)+sum_vw.*Eigen_vector(:,2))./sum_w2);%%%the estimated curvature value of the curve


%%%determine the corners by non-maximum suppression with a threshold value
KC_exp=zeros(m+2*len,1);
if curve_mode(jj,:)=='loop'
    KC_exp(len+1:len+m)=RROCC_curvature;
    KC_exp(1:len)=RROCC_curvature(m-len+1:m);
    KC_exp(m+len+1:m+2*len)=RROCC_curvature(1:len);
else
    KC_exp(len+1:len+m)=RROCC_curvature;
    KC_exp(1:len)=RROCC_curvature(len+1:-1:2);
    KC_exp(m+len+1:m+2*len)=RROCC_curvature(m-1:-1:m-len);
end


KC_med=zeros(m,2*len+1);
KC_max=-ones(m,1);

for i=1:2*len+1
    KC_med(:,i)=KC_exp(i:i+m-1);
end

for i=1:2*len+1
    KC_max=max(KC_max,KC_med(:,i));
end

locat_index=find(KC_med(:,len+1)==KC_max&K_curvature>thresh);
cout=[cout;x(locat_index) y(locat_index)];
%%%determine the corners by non-maximum suppression with a threshold value
 
end

%%%add T-corners
cd2=[];EP=0;
[cout cd3] = Refine_TJunctions(cout,TJ,cd2,curve, curve_num, curve_start, curve_end, curve_mode,EP);
%%%add T-corners

%%%show the detected corners on the original image
figure;
imshow(image);hold on;
plot(cout(:,2),cout(:,1),'r*');
%%%show the detected corners on the original image


% %%%show the detected corners on the boundary image
% figure;
% imshow(1-BW);hold on;
% plot(cout(:,2),cout(:,1),'r*');
% %%%show the detected corners on the boundary image


