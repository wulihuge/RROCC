function [filter,width] = myfilter(varargin) 
    error(nargoutchk(1,2,nargin));
    sig = varargin{1}; 
    method = 'gaussian'; % default value
    if nargin == 2
        method = varargin{2};        
    end
    if ~any(strcmp(method, {'dog','log','gaussian','bspline'}))
        error([method,' is not a valid method.']);
    end
    if strcmp(method, 'bspline')
        m = sig; n= 3; % m & n must both be integers
        width = fix(m*n/2);
        x = ones(1,m)/m;
        if n == 0
            filter = x;
        else
            filter = conv(x,x);
            for i = 1:n-1  % order of n should run conv() for n times, not n+1 times.
                filter = conv(x,filter);
            end
        end       
        return
    end
    % Magic numbers
	GaussianDieOff = .0001; 
    % Design the filters - a Laplacian of Gaussian i.e. the convolution kernel
	pw = 1:50;  % possible widths
   

%     strcmp(method,'gaussian');
    if strcmp(method,'gaussian')
         ssq = sig*sig;
        %     width = max(find(exp(-(pw.*pw)/(2*ssq))>GaussianDieOff));
        width = find(exp(-(pw.*pw)/(2*ssq))>GaussianDieOff,1,'last');
        %     width = 25;
        if isempty(width)
            width = 1;  % the user entered a really small sigma
        end
        t = (-width:width);
        
        filter = exp(-(t.*t)/(2*ssq))/(2*pi*ssq);
        filter = filter/sum(filter);
    elseif strcmp(method,'log')
         ssq = sig*sig;
        %     width = max(find(exp(-(pw.*pw)/(2*ssq))>GaussianDieOff));
        width = find(exp(-(pw.*pw)/(2*ssq))>GaussianDieOff,1,'last');
        %     width = 25;
        if isempty(width)
            width = 1;  % the user entered a really small sigma
        end
        t = (-width:width);
        
        filter = exp(-(t.*t)/(2*ssq))/(2*pi*ssq).*(t.*t/ssq-1);
    elseif strcmp(method, 'dog')
%          GaussianDieOff = .0001; 
%          pw = 1:50; 
         ssq1 = sig*sig;
         sig2 = sig+1;
         ssq2 = sig2*sig2;
         ssq = max(ssq1,ssq2);
         % 	width = max(find(exp(-(pw.*pw)/(2*ssq))>GaussianDieOff));
         width = find(exp(-(pw.*pw)/(2*ssq))>GaussianDieOff,1,'last');
         if isempty(width)
             width = 1;  
         end
         t = (-width:width);
         gau1 = exp(-(t.*t)/(2*ssq1))/(2*pi*ssq1); 
         gau2 = exp(-(t.*t)/(2*ssq2))/(2*pi*ssq2); 
         gau1=gau1/sum(gau1);
         gau2=gau2/sum(gau2);
         filter = gau2-gau1;
    end    
    

    
